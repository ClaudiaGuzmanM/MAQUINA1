package main

import (
	"bufio"
	"context"
	"fmt"
	"math/rand"
	"net"
	"os"
	"strings"
	"sync"

	pb "github.com/EdwardFlowersGg/Lab4_INF-343/proto"
	"google.golang.org/grpc"
)

var decisions []string

type server struct {
	pb.UnimplementedKFserviceServer // Embebiendo la estructura
	mutex                           sync.Mutex
	datanodes                       []string
}

func (s *server) SolicitarRegistroDataName(ctx context.Context, req *pb.RegistroDataNameRequest) (*pb.RegistroDataNameResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	// Seleccionar un DataNode aleatorio
	datanode := s.datanodes[rand.Intn(len(s.datanodes))]

	// Conectar con el DataNode seleccionado
	conn, err := grpc.Dial(datanode, grpc.WithInsecure())
	if err != nil {
		return nil, fmt.Errorf("error al conectar con el DataNode: %w", err)
	}
	defer conn.Close()

	client := pb.NewKFserviceClient(conn)
	response, err := client.SolicitarRegistrNodo(ctx, &pb.RegistroNodoRequest{
		ID:     req.ID,
		Nombre: req.Nombre,
		Piso:   req.Piso,
		Mov:    req.Mov,
	})
	if err != nil {
		return nil, fmt.Errorf("error al solicitar registro de nodo: %w", err)
	}

	record := fmt.Sprintf("%s %d %s", req.Nombre, req.Piso, datanode)
	decisions = append(decisions, record)

	// Registrar la decisión en un archivo local
	fileName := "NameNode/decisiones.txt"

	file, err := os.OpenFile(fileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return &pb.RegistroDataNameResponse{Success: false}, err
	}
	defer file.Close()

	if _, err := file.WriteString(record + "\n"); err != nil {
		return &pb.RegistroDataNameResponse{Success: false}, err
	}

	return &pb.RegistroDataNameResponse{Success: response.Success}, nil
}

func (s *server) SolicitarHistorialNameNode(ctx context.Context, req *pb.HistorialRequest) (*pb.HistorialResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	// Leer el archivo decisiones.txt para encontrar el DataNode correspondiente
	file, err := os.Open("NameNode/decisiones.txt")
	if err != nil {
		return nil, fmt.Errorf("error al abrir el archivo decisiones: %w", err)
	}
	defer file.Close()

	var datanode string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		parts := strings.Split(line, " ")
		if len(parts) == 3 && parts[0] == req.Nombre && parts[1] == fmt.Sprintf("%d", req.Piso) {
			datanode = parts[2]
			break
		}
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("error al leer el archivo decisiones: %w", err)
	}

	if datanode == "" {
		return nil, fmt.Errorf("no se encontró el DataNode para el jugador %s en el piso %d", req.Nombre, req.Piso)
	}

	// Conectar con el DataNode correspondiente
	conn, err := grpc.Dial(datanode, grpc.WithInsecure())
	if err != nil {
		return nil, fmt.Errorf("error al conectar con el DataNode: %w", err)
	}
	defer conn.Close()

	client := pb.NewKFserviceClient(conn)
	response, err := client.SolicitarHistorialDataNode(ctx, req)
	if err != nil {
		return nil, fmt.Errorf("error al solicitar historial del DataNode: %w", err)
	}

	return response, nil
}

func main() {
	// Inicializar el servidor
	lis, err := net.Listen("tcp", ":8085")
	if err != nil {
		fmt.Printf("Error al iniciar el servidor: %v\n", err)
		return
	}
	s := grpc.NewServer()
	pb.RegisterKFserviceServer(s, &server{
		datanodes: []string{"localhost:50053", "localhost:50054", "localhost:50055"},
	})
	if err := s.Serve(lis); err != nil {
		fmt.Printf("Error al servir: %v\n", err)
		return
	}
}
